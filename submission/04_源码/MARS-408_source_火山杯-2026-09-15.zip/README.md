# MARS-408：基于多智能体协同的 408 考研个性化学习系统

[![CI](https://img.shields.io/badge/CI-passing-brightgreen)](https://github.com/TrueFurina/MARS-408/actions)
[![Python](https://img.shields.io/badge/Python-3.12-blue)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-Uvicorn-009688)](https://fastapi.tiangolo.com/)
[![LangGraph](https://img.shields.io/badge/LangGraph-11--node%20pipeline-FF6F00)](https://github.com/langchain-ai/langgraph)
[![Vue](https://img.shields.io/badge/Vue-45%20views-42B883)](https://vuejs.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow)](https://github.com/TrueFurina/MARS-408)

**MARS-408** is a multi-agent personalized learning system for China's Postgraduate CS Entrance Exam ("408"): an 11-node LangGraph pipeline (triage → coordinator → diagnostician → planner → retriever → generator → assessor → critic → evidence_check → quality_gate → path_planner) delivers a full *diagnose → plan → teach → practice → review* loop, with SSE streaming, three-tier degradation (Redis/PostgreSQL/Milvus), E5 vector retrieval, and MAPPO-trained teaching policy.

> 注：MARS-408 为本系统的技术底座代号（多智能体个性化学习系统）。本项目为真实可运行的代码工程，参加 2026 福建高校「火山杯」Agent 创新大赛。

> **2026 福建高校「火山杯」Agent 创新大赛 · 参赛作品**
>
> 覆盖 408 计算机考研四科：数据结构 / 计算机组成原理 / 操作系统 / 计算机网络
>
> 代码仓库：https://github.com/TrueFurina/MARS-408
>
> 多智能体流水线：`triage` 分诊 → `coordinator` 协调员 → `diagnostician` 诊断师 → `planner` 规划师 → `retriever` 检索员 → `generator_cluster` 资源生成集群（内含 7 个角色：讲师/出题/导图/PPT/代码/视频/拓展）→ `assessor` 考官 → `critic` 审阅员 → `evidence_check` 证据核查员 → `quality_gate` 质量闸门 → `path_planner` 路径规划师

**让 AI 从"回答问题"到"真正懂你"** —— 一个由 11 节点多智能体流水线驱动的考研个性化学习教练，完成"诊断 → 规划 → 讲解 → 练习 → 复盘"的完整学习闭环。

> 本项目源于国家级大学生创新创业训练计划，本次以 MARS-408 系统参赛 2026 福建高校「火山杯」Agent 创新大赛。

---

## 〇、能力兑现状态（阅读前请先看这一节）

本项目坚持一条原则：**说得出的能力，必须指得到文件、跑得出结果。**
下表为 2026-09-12 实测核对结果，三档标注，不做模糊宣称。

| 能力 | 状态 | 实测依据 |
|---|---|---|
| 11 节点 LangGraph 流水线 | ✅ 已实现 | 全节点真跑，SSE 事件流完整至 `data: [DONE]` |
| 后端服务 | ✅ 已实现 | 冷启动 **936 ms**，加载 **2122 条**向量，`/docs` 200 |
| 真实对话生成 | ✅ 已实现 | `POST /api/chat/stream` → 200 / **5.4 s** / 有效 LLM 内容 |
| 检索增强效果 | ✅ 已实现 | **Recall@5 +10.7%**（2026-08-17 benchmark 真实产出） |
| 三级降级容灾 | ✅ 已实现 | Redis 未启用 / PostgreSQL→SQLite / Milvus→InMemory 逐级回退 |
| 前端页面 | ✅ 已实现 | **45 个 views**（82 个 .vue 含组件），学生端 + 教师看板 |
| 向量检索 | ✅ 已实现 | E5 已本地化（`models/e5-base-v2` 437MB / 768 维），`frugal_rag` 走真实向量检索，`_degraded` 关闭（2026-09-13 验证） |
| 共识与冲突消解引擎 | ✅ 规则原型 + 三评审门禁 | M2 已实施：批评者结构化输出 + 共识证据门禁 + 置信度（tests/test_m2_review_gate.py 9 用例）；GoMARL 加权共识权重仍为规则设定 |
| Triage 分级路由（M1） | ✅ 已实现 | 零 LLM 成本分类器 + low 短路快路径，tests/test_triage.py 18 用例通过 |
| LLM 通道 | ⚠️ 与文档有别 | 实际为 **DeepSeek 主 + 讯飞星火 generalv3.5**；星火 X2 未授权（`11200`） |
| FrugalRAG SFT + GRPO 真训 | ⏳ 规划中 | 后续真版目标 |
| 批评者证据门禁（M2） | ✅ 已实现 | critic 结构化 JSON + valid 证据标记 + filtered_issues 追溯 + 低置信人工复核 |
| E5 向量检索恢复 | ✅ 已实现 | E5 已本地化（`models/e5-base-v2`），向量检索主路径已启用（2026-09-13 验证） |
| MAPPO 教学策略层（M3） | ✅ 已训练（合成教学环境） | 规则监督预热 + PPO；3-seed 动态环境正确率与规则持平、成本≤规则、beginner 回合奖励 +1.9%（experiments/results/mappo_policy_eval_*.json） |
| MARL 算法实测对比（M4） | ✅ 已产出数据 | IQL / VDN / QMIX / MAPPO 教学决策 3-seed 对比：MAPPO 最优最稳（正确率 0.963±0.000 持平规则）、QMIX 次优、VDN 最差；报告见 docs/MARL算法与Agent架构对比研究.md |
| 三评审/MAPPO 生产链路集成（M5） | ✅ 端到端打通 | policy_action 由 coordinator 写入并流经全图（mock LLM 13 节点冒烟通过）；consensus 携带 confidence_score/filtered_issues；演示面板 docs/demo/三评审MAPPO演示面板.html（比赛/答辩用） |

> 上表中 ⚠️ 与 ⏳ 项**不作为项目卖点**列出；对外介绍时以此表口径为准。

---

## 一、核心能力

### 1. 11 节点多智能体流水线（LangGraph 编排）

学情诊断 → 任务规划 → 知识检索 → 资源生成 → 评估反馈 → 质量校验 → 证据核查 → 产物验收 → 路径规划，多角色各司其职、协同闭环。与传统一问一答的 Chatbot 不同，系统能主动拆解学习任务、规划学习路径、多轮交互追问，并实时反馈进度。

### 2. 共识引擎 + 冲突消解（v1 规则原型）

多个 Agent 独立作答后，由加权共识引擎裁决分歧；当 Agent 间出现知识矛盾（如"三次握手 vs 四次挥手"）时，由冲突消解引擎基于知识库证据链检索，并由真实大模型复核事实后再裁决——从机制上防控 AI 幻觉，而非仅靠提示词约束。

> **成熟度说明**：共识为 v1 规则原型（权重规则设定），已叠加三评审门禁（M2：批评者结构化输出 + 证据门禁 + 置信度阈值）。教学策略层已升级为 MAPPO（M3：`engines/mappo_policy.py`，规则预热 + PPO 训练，checkpoint 见 `models/mappo_policy.pt`），经 `use_mappo_policy` flag 灰度接入 Mixer 权重来源（默认关闭）。NeuralMixer（GroupMixerNet）权重的真训仍规划于后续真版目标。

### 3. FrugalRAG 自适应检索管线

向量检索 + BM25 全文检索 + 个性化重排 + 自适应停止策略。内置约 **2100 条知识分片与练习题**，按四科 26 大知识群组组织；检索链路异常时自动降级 BM25，保证演示与使用不中断。

> **当前状态**：E5 模型已本地化（2026-09-13 验证），向量检索分支已启用、召回达设计上限；BM25-only 为容灾降级路径（`_degraded` 标记），仅在 E5 不可用时触发。
> **E5 本地化**：模型不入库（`.gitignore` 排除 `e5-base-v2/`），会话重置/换机后运行 `python scripts/fetch_e5_model.py` 一键从 hf-mirror 恢复；恢复后向量检索自动启用。

### 4. 全链路工程化与容灾

- 前端 Vue 3 + TypeScript，**38 个页面**，多端多角色（学生 / 教师看板）
- 后端 FastAPI + LangGraph，**451 个 API 端点**（43 路由模块），**915 项测试通过 / 207 跳过**（全量回归 0 失败）
- **双通道大模型自动容灾**：DeepSeek（主）→ 讯飞星火 generalv3.5（兜底）
- Milvus / PostgreSQL / Redis 缺失时逐级自动降级，单机即可完整运行

---

## 二、系统架构

```
┌─ 前端 Vue 3 + TypeScript (45 页面 / 45 views) ───────────────┐
│  Vite :5173 → 代理 → 后端 :8002                               │
│  学生端：对话 / 学习路径 / 知识图谱 / 练习 / 评估              │
│  教师端：班级学情看板                                          │
└──────────────────────────────────────────────────────────────┘
                            │
┌─ 后端 FastAPI + LangGraph (11 节点多智能体流水线) ────────────┐
│  coordinator → diagnostician → planner → retriever             │
│    → generator_cluster → assessor → critic                     │
│    → evidence_check → quality_gate → path_planner              │
│  共识引擎(v1 规则) + 冲突消解 · FrugalRAG 检索 · 三级异常降级   │
└──────────────────────────────────────────────────────────────┘
                            │
┌─ 数据层 ──────────────────────────────────────────────────────┐
│  Milvus (向量库) / InMemoryVectorStore (降级)                  │
│  PostgreSQL / SQLite (降级) · Redis / 内存 (降级)              │
│  E5 嵌入模型 (768 维，已本地化) · 约 2100 条 · 26 知识群组      │
│  当前检索路径：向量检索主路径（E5 已本地化，异常降级 BM25-only）│
└──────────────────────────────────────────────────────────────┘
```

---

## 三、多智能体流水线（11 节点）

| 节点 | 职责 | 产出 |
|------|------|------|
| coordinator | 识别意图、全局协调、任务分派 | 任务路由 |
| diagnostician | 学情诊断，定位薄弱知识点 | 诊断报告 |
| planner | 分析画像，制定分步学习计划 | 学习计划 |
| retriever | 混合检索知识库 | 相关证据片段 |
| generator_cluster | 并行生成多种学习资源 | 讲解 / 习题 / 导图 / PPT / 视频脚本等 |
| assessor | 按知识点与难度出题、批改反馈 | 练习题 / 评分 |
| critic | 内容正确性、完整性、可读性审核 | 审核报告 |
| evidence_check | 与知识库交叉验证，标注可信度 | 证据校验报告 |
| quality_gate | 产物验收闸门（硬性质量阻断） | 验收结论 |
| path_planner | 综合评估，规划下一阶段内容 | 推荐路径 |

支持 7 种学习资源并行生成：讲解文档、练习题、思维导图、拓展阅读、PPT 大纲、代码实操、视频脚本。

---

## 四、核心功能

| 功能 | 说明 |
|------|------|
| 智能对话 | 11 节点流水线，自动识别科目、流式输出（SSE 进度） |
| 个性化学习路径 | 依据画像与薄弱点动态规划下一步学什么 |
| 知识图谱 | 四科 26 大知识群组视图（v1 规则原型） |
| 智能出题与批改 | 按科目 / 章节 / 难度生成练习并自动评分 |
| 学习效果评估 | 多维评估报告（知识点掌握 / 答题正确率 / 薄弱点变化） |
| 教师看板 | 班级学情聚合（进度 / 掌握度 / 薄弱点） |
| 408 交互教学工具 | TCP 握手动画模拟等可视化教学组件 |
| 代码沙箱 | 在线 Python 代码执行 |
| 语音朗读 | 双引擎 TTS（本地离线 + 讯飞 API） |

---

## 五、知识库与检索

| 数据 | 数量 | 说明 |
|------|------|------|
| 知识分片 | 约 1900 | knowledge_point + knowledge_variant |
| 练习题 | 200 | 选择 / 填空 / 简答，覆盖四科 |
| 向量条目 | **2122**（2026-09-13 实测加载） | 缓存二进制加载；E5 已本地化（2026-09-13 验证），重嵌入与缓存刷新按需执行 |
| 知识群组 | 26 | 按四科章节划分，供跨群冲突检测 |

检索链路：用户提问 → 向量检索（已启用）→ BM25 全文检索 → 融合排序 → 个性化重排 → 增强生成。
向量分支不可用时降级 BM25-only（`_degraded` 标记），绝不静默返回空结果。

---

## 六、量化实测（全部可复现）

| 指标 | 结果 | 说明 |
|------|------|------|
| 检索增强效果 | **Recall@5 +10.7%** | 对照无重排基线，CPU 真实运行（2026-08-17 实测） |
| 检索层可回答率基线 | answerable_rate 0.533 | 30 题四科验证集（eval_gold），持续回归用 |
| 后端冷启动 | 936 ms | 2026-09-13 实测，含 2122 条向量加载 |
| 端到端对话时延 | 5.4 s | 2026-09-02 实测，真实 LLM 流式返回 |

评测脚本随源码提供（`py-server/experiments/`），指标可一键复现——所有成效数字均为真实运行产出，不包含虚构的用户实验数据。

---

## 七、快速启动（2 分钟）

### 一键启动（Windows，推荐）

```bat
start.bat
```

自动清理 8002 / 5173 旧实例，依次拉起后端与前端。

### Docker

```bash
docker-compose up -d
# 访问 http://localhost:8002
```

> 登录账号需先注册（`/api/auth/register`）；如库内无管理员账号，注册的首个账号可用于登录。

### 本地开发

```bash
# 终端 A：后端
cd py-server && python -m venv .venv && .venv/Scripts/activate
pip install -e . && python main.py          # :8002

# 终端 B：前端
npm install && npm run dev                   # :5173，代理 /api → 8002
```

缺失 Milvus / PostgreSQL / Redis / LLM 凭证时系统自动降级，核心功能仍可演示。

---

## 八、工程指标一览

| 维度 | 指标 |
|------|------|
| 前端 | Vue 3 + TypeScript · 45 个 views（82 个 .vue） · Vite 构建 |
| 后端 | FastAPI + LangGraph · 451 个 API 端点 · 11 Agent 节点 |
| 代码量 | 后端 414 个 Python 文件 / 约 10.2 万行 · 前端 93 文件 / 约 2.8 万行 |
| 测试 | 915 项测试通过 / 207 跳过（全量回归 0 失败） |
| LLM | DeepSeek（主）+ 讯飞星火 generalv3.5（兜底）双通道自动容灾 |
| 检索 | 向量检索主路径 · 约 2122 条条目 · E5 已本地化启用（768 维） |
| 容灾 | Milvus / PG / Redis 逐级降级 · 单机可完整运行 |
| 数据 | 约 2100 条知识分片与练习题 · 26 知识群组 |

---

## 九、演示与证据

- 演示视频：`submission/03_演示视频/`
- 评测与回归脚本：`py-server/experiments/`（eval_gold / benchmark）
- 核心架构图：`documents/MARS-408核心架构图.svg`
- 项目体检报告：`diagnostics/项目体检报告-2026-09-02.md`（宣称与实测逐条核对）

---

## 十、开发工具合规声明

本项目为真实可运行的代码工程（Vue 3 + TypeScript 前端 / FastAPI + LangGraph 后端），采用 **Trae**（字节跳动 AI IDE）作为开发工具完成核心模块的开发与迭代；代码仓库可在 Trae 中直接打开、构建并运行，满足 2026 福建高校「火山杯」Agent 创新大赛"基于 Trae 开发"的工具要求。

关键模块清单：`py-server/agents/graph.py`（多智能体流水线）、`py-server/engines/frugal_rag.py`（检索引擎）、`py-server/engines/gomarl.py`（共识引擎）、`src/`（前端页面）。

---

*本 README 数据口径与源码一致；第〇节「能力兑现状态」为权威口径，量化指标均可通过随源码提供的脚本复现。*
