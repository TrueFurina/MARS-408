import faulthandler
faulthandler.dump_traceback_later(25, exit=False)
import uvicorn
uvicorn.run("main:app", host="127.0.0.1", port=8006)
