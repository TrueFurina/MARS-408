import importlib
import sys
# Simulate what conftest does
sys.path.insert(0, r'E:\Program\MARL\study-help-pro\py-server')
import db.llm_provider as _lp
importlib.reload(_lp)
print(f"type={type(_lp.LLMProvider)}")
print(f"mro={_lp.LLMProvider.__mro__}")
print(f"has chat={hasattr(_lp.LLMProvider, 'chat')}")

# Now simulate what mock_auth does - import main
from main import app
import db.llm_provider as _lp2
print(f"\nAfter main import:")
print(f"type={type(_lp2.LLMProvider)}")
print(f"mro={_lp2.LLMProvider.__mro__}")
print(f"has chat={hasattr(_lp2.LLMProvider, 'chat')}")