import importlib
import db.llm_provider as m
importlib.reload(m)
print(f"type={type(m.LLMProvider)}")
print(f"repr={repr(m.LLMProvider)}")
print(f"has chat={hasattr(m.LLMProvider, 'chat')}")