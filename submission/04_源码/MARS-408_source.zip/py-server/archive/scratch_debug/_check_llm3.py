import sys
sys.path.insert(0, r'E:\Program\MARL\study-help-pro\py-server')

# Try to reproduce the exact pytest conftest order
import tests.conftest as _c
print("conftest imported OK")

# Now simulate the mock_llm fixture
import db.llm_provider as _lp
print(f"LLMProvider type: {type(_lp.LLMProvider)}")
print(f"LLMProvider mro: {_lp.LLMProvider.__mro__}")
print(f"has chat: {hasattr(_lp.LLMProvider, 'chat')}")