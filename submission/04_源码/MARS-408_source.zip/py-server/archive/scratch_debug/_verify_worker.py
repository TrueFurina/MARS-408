import sys
sys.path.insert(0, '.')
from services.import_worker import _resolve_uvicorn_workers
print('F6 _resolve_uvicorn_workers() =', _resolve_uvicorn_workers())