import sys, json, urllib.request, urllib.error

BASE = "http://127.0.0.1:8002"

def req(method, path, token=None, body=None):
    url = BASE + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=120) as resp:
            return resp.status, resp.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")

# 1) 登录
s, raw = req("POST", "/api/auth/login", body={"username": "demo", "password": "demo123456"})
print(f"LOGIN HTTP {s} | raw={raw[:200]}")
d = json.loads(raw) if raw else {}
token = d.get("token") or d.get("access_token") or ""
print(f"TOKEN len={len(token)}  keys={list(d.keys())}")

# 2) 真实 X2 主通道：/api/tutor/answer
s2, raw2 = req("POST", "/api/tutor/answer", token=token, body={
    "question": "简述TCP三次握手过程",
    "course": "computer_network",
    "generate_diagram": False,
    "quick_mode": False,
})
print(f"\nTUTOR HTTP {s2}")
print(raw2[:900])
