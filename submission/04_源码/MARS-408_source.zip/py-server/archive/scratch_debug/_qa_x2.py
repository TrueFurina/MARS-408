import json
import time
import urllib.request

BASE = "http://127.0.0.1:8002"
USER = f"qa_probe_{int(time.time())}"
PW = "qa_probe_pass_2026"

out = []


def call(method, path, token=None, data=None):
    url = BASE + path
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {"raw": e.read().decode()[:300]}
    except Exception as e:  # noqa
        return None, {"error": type(e).__name__ + ": " + str(e)[:200]}


st, payload = call("POST", "/api/auth/register", data={"username": USER, "password": PW, "display_name": "QA Probe"})
out.append(f"register({USER}): HTTP {st}")
if st == 200 and "token" in payload:
    token = payload["token"]
else:
    out.append(f"register failed ({st}): {json.dumps(payload)[:200]}")
    token = None

if not token:
    out.append("NO_TOKEN: cannot call x2-health (auth failed)")
    with open("_qa_x2.log", "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    raise SystemExit(0)

st, payload = call("GET", "/api/llm/x2-health", token=token)
out.append(f"x2-health: HTTP {st}")

probed = payload.get("probed", []) if isinstance(payload, dict) else []
ok_list = [p for p in probed if p.get("ok")]
summary = {
    "xfyun_configured": payload.get("xfyun_configured") if isinstance(payload, dict) else None,
    "current": payload.get("current") if isinstance(payload, dict) else None,
    "probed_count": len(probed),
    "ok_count": len(ok_list),
    "ok_labels": [p.get("label") for p in ok_list],
    "all_http_codes": [p.get("http_code") for p in probed],
}
out.append("SUMMARY: " + json.dumps(summary, ensure_ascii=False))
out.append("RECOMMENDATION: " + (payload.get("recommendation", "") if isinstance(payload, dict) else str(payload)[:300]))

with open("_qa_x2.log", "w", encoding="utf-8") as f:
    f.write("\n".join(out) + "\n")
print("DONE")
