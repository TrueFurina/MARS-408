import sys, json, asyncio
sys.path.insert(0, '.')
import httpx
from config import load_config

config = load_config()
xf = config.get("xfyun", {})
pw = xf.get("api_password", "")
HEADERS = {"Authorization": f"Bearer {pw}", "Content-Type": "application/json"}
BODY = {
    "messages": [{"role": "user", "content": "用一句话解释TCP三次握手"}],
    "temperature": 0.3,
    "max_tokens": 50,
}

async def probe(name, url, model):
    b = dict(BODY); b["model"] = model
    print(f"\n──── 探针 [{name}] url={url} model={model} ────")
    try:
        async with httpx.AsyncClient(timeout=40) as c:
            r = await c.post(url, headers=HEADERS, json=b)
            snippet = (r.text or "")[:300]
            print(f"HTTP {r.status_code} | {snippet}")
    except Exception as e:
        print(f"EXCEPTION: {repr(e)}")

async def main():
    # 1) 测两个预设端点
    presets = xf.get("presets", {})
    if "4.0Ultra" in presets:
        p = presets["4.0Ultra"]
        await probe("4.0Ultra预设", p["base_url"], p["model"])
    if "spark_x2" in presets:
        p = presets["spark_x2"]
        await probe("spark_x2预设", p["base_url"], p["model"])

    # 2) 走完整 LLMProvider auto 模式，确认第一优先级 X2 是否真正被用上
    from db.llm_provider import LLMProvider
    lp = LLMProvider()
    info = lp.get_provider_info()
    print("\n──── LLMProvider.auto 解析结果（脱敏）────")
    print(json.dumps({k: (v if k != "api_password" else "****") for k, v in info.items()}, ensure_ascii=False))
    print("→ 第一优先级通道将被选为:", info.get("name"))
    resp = await lp.chat([{"role": "user", "content": "用一句话解释TCP三次握手"}], max_tokens=50, temperature=0.3)
    # 讯飞返回体含 sid/choices；DeepSeek 是 OpenAI 格式
    ch = resp.get("choices", [{}])[0].get("message", {}).get("content", "")
    sid = resp.get("sid")
    print(f"→ chat() 是否含讯飞 sid(证明走的是 X2 而非 DeepSeek): {sid}")
    print(f"→ 回复片段: {ch[:80]}")

asyncio.run(main())
