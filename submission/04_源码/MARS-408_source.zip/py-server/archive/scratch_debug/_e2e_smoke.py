import os, logging, time
logging.getLogger('httpx').setLevel(logging.WARNING)
os.environ.setdefault('AUTH_SECRET', 'smoke-secret')
from fastapi.testclient import TestClient
from main import app
import shared.auth as auth
app.dependency_overrides[auth.get_current_user] = lambda: {'id': 'u1', 'username': 'smoke', 'role': 'admin'}
c = TestClient(app)
PNG = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M8AAAMBAQDJ/pLvAAAAAElFTkSuQmCC"

def call(name, method, path, json=None):
    try:
        r = c.request(method, path, json=json)
        print(f'{name}: HTTP {r.status_code} | {str(r.json())[:170]}', flush=True)
    except Exception as e:
        print(f'{name}: ERR {type(e).__name__}: {str(e)[:140]}', flush=True)

print('=== 成功路径验证 ===', flush=True)
call('SEARCH', 'POST', '/api/xfyun/search', {'query': 'TCP三次握手', 'limit': 3})
call('PROOFREAD', 'POST', '/api/xfyun/proofread', {'text': '画蛇天足是常见错误写法'})
call('COMPLIANCE', 'POST', '/api/xfyun/compliance', {'text': '正常学习笔记'})
call('IMAGE_UNDERSTAND', 'POST', '/api/xfyun/image-understand', {'image_base64': PNG, 'question': '图里有什么'})

print('--- PPT ---', flush=True)
r = c.post('/api/xfyun/ppt', json={'query': '操作系统进程调度', 'is_figure': True, 'search': True})
tid = (r.json() or {}).get('task_id')
print(f'PPT_SUBMIT: HTTP {r.status_code} | task_id={tid}', flush=True)
for i in range(6):
    try:
        s = c.get(f'/api/xfyun/ppt/status/{tid}').json()
        print(f'  PPT status[{i}]: {s.get("status")} | {str(s.get("result"))[:70]}', flush=True)
        if s.get('status') in ('done', 'failed'):
            break
    except Exception as e:
        print('  PPT status err', e, flush=True)
    time.sleep(6)

print('--- VIDEO ---', flush=True)
r2 = c.post('/api/xfyun/video', json={'prompt': '讲解操作系统进程调度', 'word_count': 60})
print(f'VIDEO_SUBMIT: HTTP {r2.status_code} | task_id={(r2.json() or {}).get("task_id")}', flush=True)
print('=== DONE ===', flush=True)
