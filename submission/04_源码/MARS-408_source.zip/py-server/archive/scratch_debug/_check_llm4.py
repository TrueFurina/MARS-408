import sys
sys.path.insert(0, "E:/Program/MARL/study-help-pro/py-server")
import tests.conftest as c
import db.llm_provider as lp
print("type:", type(lp.LLMProvider))
print("has chat:", hasattr(lp.LLMProvider, "chat"))