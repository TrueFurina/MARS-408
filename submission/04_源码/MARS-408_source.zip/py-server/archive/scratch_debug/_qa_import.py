import importlib, subprocess, sys, os

# CORRECTED conservative subset using real module filenames (avoids torch/numpy SEGV modules)
MODS = [
    "config",
    "shared.errors",
    "shared.auth",
    "shared.dependencies",
    "db.llm_provider",
    "db.user_store",
    "db.redis_client",
    "db.pg_client",
    "db.skill_store",
    "db.xfyun_services",
    "api.auth",
    "api.chat",
    "api.llm_health",
    "api.knowledge",
    "api.subjects",
    "api.profile",
    "services.import_worker",
    "seed_data",
]

os.chdir(os.path.dirname(os.path.abspath(__file__)))
results = []
for m in MODS:
    code = (
        "import importlib,sys\n"
        "importlib.import_module(%r)\n"
        "print('IMPORT_OK', %r)\n"
    ) % (m, m)
    try:
        r = subprocess.run(
            [sys.executable, "-c", code],
            cwd=os.getcwd(),
            capture_output=True, text=True, timeout=90,
        )
    except subprocess.TimeoutExpired:
        results.append((m, False, "TIMEOUT", ""))
        continue
    ok = r.returncode == 0 and "IMPORT_OK" in r.stdout
    tail = (r.stderr or r.stdout).strip().splitlines()
    tail = tail[-2:] if tail else []
    results.append((m, ok, r.returncode, " | ".join(tail)))

with open("_qa_import2.log", "w", encoding="utf-8") as f:
    for m, ok, rc, tail in results:
        f.write(f"{'OK  ' if ok else 'FAIL'} {m} rc={rc} :: {tail}\n")
    passed = sum(1 for _, ok, _, _ in results if ok)
    f.write(f"\nSUMMARY: {passed}/{len(results)} modules imported OK\n")
print(f"DONE: {passed}/{len(results)}")
