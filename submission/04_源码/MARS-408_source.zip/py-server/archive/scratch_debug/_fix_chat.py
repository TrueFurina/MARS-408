data = open('api/chat.py', 'rb').read()
# Fix all indentation issues in the chat_send function
fixed = data.replace(b'\n\nif reply:', b'\n\n    if reply:')
fixed = fixed.replace(b'\n        )\n\nexcept LLMUnavailable as e:', b'\n        )\n    except LLMUnavailable as e:')
open('api/chat.py', 'wb').write(fixed)
print('Fixed chat.py indentation')