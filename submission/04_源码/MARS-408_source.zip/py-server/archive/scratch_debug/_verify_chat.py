import sys
sys.path.insert(0, '.')
from api.chat import router
print('chat.py import OK')