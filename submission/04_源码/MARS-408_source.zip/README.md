# MARS-408 — 408 考研个性化学习多智能体系统

[![Python](https://img.shields.io/badge/python-3.12+-blue)]()
[![Vue](https://img.shields.io/badge/vue-3-brightgreen)]()
[![FastAPI](https://img.shields.io/badge/FastAPI-0.136+-009688)]()
[![Tests](https://img.shields.io/badge/tests-554_passing-green)]()
[![License](https://img.shields.io/badge/license-%E5%8F%82%E8%80%83-blue)]()

基于借鉴 **GOMARL** 架构的加权共识门与借鉴 **FrugalRAG** 思路的检索管线的 408 考研个性化学习平台。

> 🏆 **第十五届中国软件杯 A3 赛题参赛作品** | 出题企业：科大讯飞
> 🎯 覆盖数据结构 / 计算机组成原理 / 操作系统 / 计算机网络

---

## 目录

- [系统架构](#系统架构)
- [环境要求](#环境要求)
- [快速启动](#快速启动)
- [Docker 部署](#docker-部署)
- [项目结构](#项目结构)
- [核心功能](#核心功能)
- [FrugalRAG 知识库](#frugalrag-知识库)
- [多智能体协作](#多智能体协作)
- [TTS 语音朗读](#tts-语音朗读)
- [API 概览](#api-概览)
- [赛题要求对应表](#赛题要求对应表)
- [配置说明](#配置说明)
- [数据模型](#数据模型)
- [常见问题](#常见问题)
- [测试](#测试)
- [文档](#文档)

---

## 系统架构

```
┌─ 前端 (Vue 3 + TypeScript) ────────────────────────────────┐
│  Vite 5173 → 代理 → 后端 8002                                │
│  36 视图 / 31 组件 / Pinia 状态管理 / Vue Router              │
└─────────────────────────────────────────────────────────────┘
                           │
┌─ 后端 (FastAPI + LangGraph) ────────────────────────────────┐
│  10 节点多智能体流水线 (coordinator → planner → generator →   │
│    tutor → assessor → critic → evidence_check → ...)         │
│  GOMARL 共识引擎 + NeuralMixer 神经网络                      │
│  FrugalRAG 检索 (E5 + BM25 + 个性化重排)                     │
│  7 种资源并行生成 (讲解/习题/导图/代码/PPT/视频/拓展)         │
│  TTS 双引擎 (MeloTTS 本地离线 + 讯飞 API)                    │
│  196 API 端点 | JWT 认证                                    │
└─────────────────────────────────────────────────────────────┘
                           │
┌─ 数据层 ────────────────────────────────────────────────────┐
│  Milvus (向量库) / InMemoryVectorStore (开发回退)              │
│  PostgreSQL / SQLite (回退) | Redis (缓存)                    │
│  E5 嵌入模型 (768 维) | 1883 知识 chunks + 200 题              │
└─────────────────────────────────────────────────────────────┘
```

---

## 环境要求

| 组件 | 最低版本 | 备注 |
|------|---------|------|
| Python | ≥ 3.12 | 必须 |
| Node.js | ≥ 20.19 或 ≥ 22.12 | 必须 |
| Bun | 最新版 | 前端依赖管理，也可用 npm |
| Git | 任意版 | 克隆代码 |

### 可选依赖（不安装自动降级）

| 组件 | 用途 | 降级行为 |
|------|------|---------|
| Milvus + pymilvus | 向量检索 | 自动回退 InMemoryVectorStore |
| PostgreSQL | 持久化存储 | 自动回退 SQLite |
| Redis | 缓存/会话 | 内存降级，功能不受影响 |

---

## 快速启动（5 分钟）

### 1. 克隆项目

```bash
git clone <仓库地址> study-help-pro
cd study-help-pro
```

### 2. 安装前端依赖

```bash
bun install
# 或 npm install
```

### 3. 安装后端依赖

```bash
cd py-server
python -m venv .venv

# Windows
.venv\Scripts\activate
# macOS / Linux
# source .venv/bin/activate

pip install -e .
```

### 4. 配置环境变量

```bash
# 复制模板
cp .env.example .env
# Windows: copy .env.example .env
```

编辑 `.env`，填入你的 API 密钥：

```ini
# ── LLM 通道（至少填一个）──
# 主通道：讯飞星火 X2（赛题合规要求，深度使用出题企业科大讯飞能力）
XF_API_KEY=your-key
XF_API_SECRET=your-secret

# 兜底：DeepSeek（运行时韧性兜底，非开发工具；讯飞不可用时自动切换）
DEEPSEEK_API_KEY=sk-your-key-here

# ── 安全（生产环境必填）──
AUTH_SECRET=your-random-secret-string     # JWT 签名密钥，不填则每次重启随机生成（已签发 Token 失效）
ADMIN_PASSWORD=your-admin-password        # 管理员密码，不填则随机生成

# ── 可选 ──
CORS_ORIGINS=http://localhost:5173        # 跨域白名单，多个用逗号分隔
NETLEARN_ENV=development                  # production 会禁用演示账号、强制安全配置
```

**环境变量完整参考：**

| 变量 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `DEEPSEEK_API_KEY` | 否 | — | DeepSeek 兜底通道密钥（讯飞不可用时自动切换） |
| `XF_API_KEY` | 推荐 | — | 讯飞星火 X2 主通道 API Key |
| `XF_API_SECRET` | 推荐 | — | 讯飞星火 X2 主通道 API Secret |
| `AUTH_SECRET` | 生产必填 | 随机生成 | JWT HMAC-SHA256 签名密钥 |
| `ADMIN_PASSWORD` | 生产必填 | 随机生成 | 管理员账号密码 |
| `CORS_ORIGINS` | 否 | `http://localhost:5173` | 跨域白名单 |
| `HF_HUB_OFFLINE` | 否 | `1` | HuggingFace 离线模式（避免每次请求卡 90s 重试） |
| `NETLEARN_ENV` | 否 | `development` | 环境模式 |
| `STATIC_DIR` | 否 | `../dist` | 前端 SPA 静态文件目录 |

> 没有 API 密钥也可以启动，但 LLM 功能不可用，部分演示数据会显示降级提示。

### 5. 启动后端

```bash
# 确保在 py-server 目录下，虚拟环境已激活
python main.py
```

后端启动在 **http://127.0.0.1:8002**，健康检查：

```bash
curl http://127.0.0.1:8002/api/status
```

### 6. 启动前端（新开终端）

```bash
# 回到项目根目录
cd study-help-pro
bun dev
# 或 npm run dev
```

前端启动在 **http://127.0.0.1:5173**，Vite 自动代理 `/api` 请求到后端 8002 端口。

### 7. 打开浏览器

访问 **http://127.0.0.1:5173** → 注册账号 → 开始使用

> 演示账号（非生产环境）：`demo` / `demo123456`

---

## Docker 部署

### 开箱即跑（评委默认）

```bash
docker-compose up -d
```

- development 模式：自动生成 AUTH_SECRET / ADMIN_PASSWORD，播种 demo/demo123456 演示账号
- 无 Milvus 时自动降级 InMemoryVectorStore，功能完整
- 浏览器访问 `http://localhost:8002`，登录 `demo` / `demo123456`

### 完整部署（含 Milvus + Redis）

```bash
# 生产环境需先配置 .env（必填 AUTH_SECRET >= 32字符 / ADMIN_PASSWORD >= 16字符）
# NETLEARN_ENV=production
# AUTH_SECRET=<your-random-secret>
# ADMIN_PASSWORD=<your-strong-password>
docker-compose --profile production up -d
```

> ⚠️ 生产模式下缺失 AUTH_SECRET 或 ADMIN_PASSWORD 会导致 fail-fast 启动失败（安全设计）。

### 启动带 Milvus 的完整服务

```bash
docker compose --profile milvus up -d
```

- 拉起应用服务与 Milvus（standalone），`config.json` 中 `milvus.enabled=true` 生效
- 首次启动自动写入种子数据，依据 `agents/kg_dag.chapter_to_group` 为每条 chunk 注入 `metadata.group`（1–26），供证据校验做跨群冲突检测

### 仅应用服务（开发测试）

```bash
docker compose up -d app
```

### 无 Docker 本地开发

```bash
# 终端 A：后端
cd py-server && python main.py

# 终端 B：前端
cd study-help-pro && npm run dev     # 或 bun dev
```

未带 `--profile milvus` 启动时向量库回退 InMemory，证据校验等功能不受影响。

### 快速验证（启动后核对）

```bash
# 健康检查 — 期望 vector_db=inmemory, collection_size>0
curl http://127.0.0.1:8002/api/status

# 指标端点 — 期望 Prometheus 文本格式输出
curl http://127.0.0.1:8002/metrics
```

期望 `/api/status` 响应：

```json
{
  "status": "ok",
  "vector_db": "inmemory",
  "collection_size": 1883,
  "llm_available": false
}
```

- `vector_db`: `inmemory`（无 Milvus 降级）或 `milvus`（完整）
- `collection_size`: `> 0` 表示种子知识库已加载
- `llm_available`: `false` 表示 demo 模式（未配 LLM 凭证，核心链路用内置样例运行）

> 详细部署核对表见 [`docs/deployment-checklist.md`](docs/deployment-checklist.md)

### 验收脚本

```bash
python py-server/scripts/verify_kb_coverage.py   # 校验四科 group 覆盖与可检索性
```

---

## 项目结构

```
study-help-pro/
├── src/                        # 前端 Vue 3 源码
│   ├── views/                  # 页面视图 (25 个)
│   ├── components/             # 公共组件 (18 个)
│   ├── stores/                 # Pinia 状态管理
│   ├── router/                 # 路由配置
│   └── utils/                  # 工具函数 (API/渲染/安全)
├── py-server/                  # 后端 Python 源码
│   ├── api/                    # API 路由 (26 个模块, 100+ 端点)
│   ├── agents/                 # 多智能体节点 (10 个)
│   ├── engines/                # 核心引擎 (GOMARL/FrugalRAG/...)
│   ├── db/                     # 数据层 (LLM/向量库/PG/Redis)
│   ├── services/               # 业务服务 (TTS/导入队列/...)
│   ├── shared/                 # 共享工具 (认证/错误/审计)
│   ├── tools/                  # 工具脚本 (PPT/视频生成)
│   ├── models/                 # E5 嵌入模型 + 训练权重
│   └── tests/                  # 测试 (614+ 个用例，全量 554 passed)
├── documents/                  # 项目文档 (50+ 份)
├── docs/                        # 设计文档 + 报告 (docs/reports/、docs/design-system/)
├── references/                  # 外部参考资料
├── scripts/                     # 工具脚本 (启动/构建/质检)
├── submission/                  # 竞赛交付包 (源码 zip 等)
├── archive/                     # 历史快照 (参赛包/旧构建/日志，gitignore)
├── docker-compose.yml          # Docker 编排
├── Dockerfile                  # 多阶段构建
└── vite.config.ts              # 前端构建配置
```

---

## 核心功能

| 功能 | 说明 | 入口 |
|------|------|------|
| **智能对话** | 10 节点多智能体流水线，自动识别科目生成学习资源 | `/chat` |
| **智能出题** | 按科目/章节/难度生成练习题，含答题评估 | `/practice` |
| **知识图谱** | 四科知识图谱可视化，知识点关联浏览 | `/knowledge` |
| **学习路径** | 个性化学习路径规划，薄弱点优先 | `/learning-path` |
| **资源生成** | 7 种资源并行生成（讲解/习题/导图/代码/PPT/视频/拓展） | `/resource` |
| **语音朗读** | 双引擎 TTS（MeloTTS 本地离线 + 讯飞 API），6 种语言朗读 | 对话/资源页 🔊 按钮 |
| **算法引擎** | GOMARL 共识 / FrugalRAG 检索 / NeuralMixer 可视化 | `/engine` |
| **学习评估** | 多维学习效果评估报告 | `/assessment` |
| **代码沙箱** | 在线 Python 代码执行环境 | `/sandbox` |
| **讯飞能力** | 图片理解/PPT生成/数字人视频/文本纠错/简历生成 | `/xfyun` |
| **容灾可观测** | 熔断器 + 令牌桶实时状态可视化（多级兜底降级） | `/engine` |
| **Skill 工具元数据** | 技能可配置结构化工具（OpenAI function schema，LLM 按元数据选工具） | `/studio` |
| **记忆权限配置** | 技能 L1/L2/L3 记忆读写四档权限（none/read/write/read_write） | `/studio` |
| **教师看板** | 真实学生数据聚合（进度/掌握度/薄弱点/班级分析） | `/teacher` |

---

## FrugalRAG 知识库

### 核心架构

```
408教材PDF → pymupdf提取 → 语义分块 → E5嵌入(768维) → VectorDB(Milvus/InMemory)
                                                                      ↓
用户提问 → E5向量检索 → BM25全文检索 → 融合排序 → Reranker精排 → 增强生成
```

### 知识库规模

| 数据来源 | 数量 | 说明 |
|---------|------|------|
| 内置种子数据 | 1883 chunks | 四科核心知识点，手动编写 |
| 教材 PDF 导入 | 自动扩充 | 启动时自动扫描 `documents/教材/` 并导入 |
| 练习题 | 200+ 题 | 选择题/填空题/简答题，覆盖四科 |

### 检索流程

1. **E5 向量检索** — 语义相似度搜索，768 维嵌入，余弦相似度排序
2. **BM25 全文检索** — 关键词匹配，作为向量检索的补充
3. **融合排序** — 加权融合向量检索和 BM25 结果
4. **Reranker 重排** — Cross-encoder 精排，提升 Top-K 准确性
5. **Frugal 策略** — 借鉴 FrugalRAG 思路的自适应停止策略，基于阈值与置信度决定检索时机，减少不必要的 RAG 调用

### API 查询

```bash
# 查询知识库状态
curl http://localhost:8002/api/rag/status -H "Authorization: Bearer <token>"

# 语义搜索知识库
curl -X POST http://localhost:8002/api/rag/search \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"query":"TCP三次握手","course":"computer_network","top_k":5}'
```

---

## 多智能体协作

### 流水线

```
用户提问 → Coordinator(coordinator)
  → Planner(规划师) 制定学习计划
  → Retriever(检索器) 搜索知识库
  → Generator(讲师) 生成讲解文档
  → Tutor(助教) 答疑解惑
  → Assessor(考官) 出题测试
  → Critic(审阅员) 质量审核
  → EvidenceCheck(证据校验) 事实核查
  → PathPlanner(路径规划) 推荐下一步
```

### 各节点职责

| 节点 | 职责 | 产出 |
|------|------|------|
| `coordinator` | 识别用户意图，分派任务到对应子 Agent | 任务路由 / 技能选择 |
| `planner` | 分析学生画像，制定分步学习计划 | 学习路径 / 知识点排序 |
| `retriever` | 搜索知识库（向量 + BM25 混合检索），联网补充 | 相关文档片段 / 引用来源 |
| `generator` | 生成教学讲解文档，含图示、例子、考点标注 | 教学文档 (Markdown) |
| `tutor` | 实时答疑解惑，支持追问和举一反三 | 问答回复 / 代码示例 |
| `assessor` | 根据知识点和难度出题，批改并反馈 | 练习题 / 评分报告 |
| `critic` | 质量审核：检查内容正确性、完整性、可读性 | 审核报告 / 修改建议 |
| `evidence_check` | 事实核查：与知识库交叉验证，标注可信度 | 证据校验报告 / 置信度评分 |
| `path_planner` | 综合评估结果，规划下一阶段学习内容 | 推荐路径 / 薄弱点提示 |

### 资源生成类型（≥7 种，赛题要求 ≥5 种）

| 序号 | 资源类型 | 生成 Agent | 说明 |
|------|---------|-----------|------|
| 1 | 📖 讲解文档 | generator | 知识点详细讲解，含图示和考点 |
| 2 | 📝 练习题 | assessor | 选择题/填空题/简答题，含答案解析 |
| 3 | 🎨 思维导图 | generator | Mermaid 格式知识图谱 |
| 4 | 📚 拓展阅读 | generator | 论文/前沿动态/开源项目推荐 |
| 5 | 📊 PPT 大纲 | ppt_outline | 8-12 页幻灯片结构化大纲 |
| 6 | 💻 代码实操 | code_practice | 可运行 Python 代码案例 |
| 7 | 🎬 视频脚本 | video_script | 分镜脚本 + 旁白文案 |

---

## TTS 语音朗读

### 引擎对比

| 引擎 | 类型 | 语言支持 | 延迟 | 费用 | 适用场景 |
|------|------|---------|------|------|---------|
| **MeloTTS** | 本地离线 | 中/英/日/韩/西/法 | ~300ms (CPU) | 免费 | 批量配音、演示环境、离线部署 |
| **讯飞 TTS API** | 在线 API | 中/英 | ~200ms | 按调用量计费 | 实时交互、展示出题企业能力 |

### 路由策略

```
用户交互（实时朗读）       → 优先 MeloTTS（离线，免费）
批量资源配音（视频/PPT）   → MeloTTS（无配额限制）
演示环境 / 离线模式        → MeloTTS（不依赖网络）
有讯飞凭证时               → 自动 fallback：MeloTTS 失败后尝试讯飞
```

### 朗读按钮位置

- **对话页面**：每条 AI 回复右侧 🔊 按钮
- **资源生成页面**：讲解文档、练习题、拓展阅读、PPT大纲、代码案例、视频脚本

### API 调用

```bash
# 查询 TTS 引擎状态
curl http://localhost:8002/api/tts/status \
  -H "Authorization: Bearer <token>"

# 语音合成
curl -X POST http://localhost:8002/api/tts/synthesize \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"text":"你好，欢迎学习计算机网络","language":"zh","engine":"auto"}' \
  --output lecture.wav
```

---

## API 概览

所有 API 以 `/api` 为前缀，需携带 `Authorization: Bearer <token>` 请求头。

### 认证

```bash
# 登录获取 token
curl -X POST http://localhost:8002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"demo","password":"demo123456"}'
# 返回: {"token":"eyJ...", "user":{...}}

# 健康检查（无需认证）
curl http://localhost:8002/api/status
```

### 核心端点

| 路由 | 方法 | 说明 | 认证 |
|------|------|------|------|
| `/api/status` | GET | 健康检查 / 系统状态 | ❌ |
| `/api/auth/login` | POST | 登录获取 Token | ❌ |
| `/api/auth/register` | POST | 注册新用户 | ❌ |
| `/api/chat/send` | POST | 聊天对话（流式 SSE） | ✅ |
| `/api/agents/generate-resource` | POST | 多智能体资源生成（SSE 进度推送） | ✅ |
| `/api/tts/synthesize` | POST | 单段文本语音合成 | ✅ |
| `/api/tts/batch` | POST | 批量文本语音合成（zip 打包） | ✅ |
| `/api/tts/status` | GET | TTS 引擎状态 | ✅ |
| `/api/quiz/generate` | POST | 生成练习题 | ✅ |
| `/api/quiz/submit` | POST | 提交答案并评分 | ✅ |
| `/api/profile/get` | GET | 获取学生画像 | ✅ |
| `/api/profile/update` | POST | 更新学生画像 | ✅ |
| `/api/learning-path/generate` | POST | 生成学习路径 | ✅ |
| `/api/learning-path/recommend` | POST | 推荐下一步学习内容 | ✅ |
| `/api/knowledge/graph` | GET | 知识图谱数据 | ✅ |
| `/api/multimodal/generate-image` | POST | 生成教学插图 | ✅ |
| `/api/multimodal/generate-audio` | POST | 生成教学音频 | ✅ |
| `/api/sandbox/run` | POST | 代码沙箱执行 Python | ✅ |
| `/api/xfyun/understand-image` | POST | 讯飞图片理解 | ✅ |
| `/api/xfyun/generate-ppt` | POST | 讯飞智能 PPT 生成 | ✅ |
| `/api/xfyun/generate-video` | POST | 讯飞数字人视频生成 | ✅ |
| `/api/assessment/evaluate` | POST | 学习效果评估 | ✅ |
| `/api/assessment/report` | GET | 获取评估报告 | ✅ |

> 完整 OpenAPI Schema 见 `documents/openapi_schema.json`（约 450KB），可用 Swagger UI 导入浏览。

---

## 赛题要求对应表

> 第十五届中国软件杯 A3 赛题：**"基于大模型的个性化资源生成与学习多智能体系统开发"**

| 赛题要求 | 实现 | 状态 |
|---------|------|:----:|
| **1. 对话式学习画像自主构建**（≥6 维度，随学随新） | 多轮对话自动抽取特征，6 维度画像（知识基础/认知风格/易错点/学习偏好/进度/目标），每次交互后动态更新 | ✅ |
| **2. 多智能体协同资源生成**（≥5 种资源类型） | 7 种资源并行生成：讲解文档 / 练习题 / 思维导图 / 拓展阅读 / PPT 大纲 / 代码实操 / 视频脚本 | ✅ |
| **3. 个性化学习路径规划和资源推送** | KG-DAG 路径规划 + 个性化重排，依据画像和薄弱点动态调整推送策略 | ✅ |
| **4. 智能辅导（可选加分项）** | Tutor Agent 多模态答疑，支持文字解答 + 图解说明 + 代码示例 + 语音朗读 | ✅ |
| **5. 学习效果评估（可选加分项）** | 多维度评估（知识点掌握/答题正确率/学习时长/薄弱点变化），动态调整学习方案 | ✅ |
| **多模态生成（视频/动画）** | 讯飞 TTI 教学插图 + MeloTTS/讯飞 TTS 语音 + 数字人视频大模型 | ✅ |
| **防幻觉与内容安全** | EvidenceCheck 事实核查 + 敏感词过滤 + 四角色交叉验证 | ✅ |
| **流式输出 / 进度追踪** | SSE 推送 Agent 实时进度 + 进度条百分比 | ✅ |
| **使用科大讯飞相关工具** | 深度集成讯飞 10 项能力（TTI/图片理解/万搜/PPT/数字人/纠错/校对/合规/角色模拟/简历） | ✅ |

---

## 配置说明

### 配置文件

系统配置位于 `py-server/config.json`，主要配置项：

| 配置路径 | 类型 | 说明 |
|---------|------|------|
| `llm_provider` | string | LLM 通道选择：`auto`（默认，讯飞星火 X2 优先）/ `xfyun` / `deepseek` |
| `deepseek.api_key` | string | DeepSeek API 密钥 |
| `deepseek.base_url` | string | DeepSeek 端点（默认 `https://api.deepseek.com`） |
| `deepseek.model` | string | 模型名（默认 `deepseek-chat`） |
| `xfyun.app_id` | string | 讯飞应用 ID |
| `xfyun.api_key` | string | 讯飞 API Key |
| `xfyun.api_secret` | string | 讯飞 API Secret |
| `milvus.enabled` | bool | 是否启用 Milvus（默认 `true`） |
| `milvus.host` | string | Milvus 主机（默认 `localhost`） |
| `postgresql.enabled` | bool | 是否启用 PostgreSQL（默认 `false`） |
| `redis.enabled` | bool | 是否启用 Redis（默认 `false`） |

> 环境变量优先级高于 `config.json`。

### 修改端口

```python
# py-server/main.py 末尾
uvicorn.run("main:app", host="127.0.0.1", port=8002, reload=reload_mode)
```

同时同步修改 `vite.config.ts` 中的 proxy target。

---

## 数据模型

| 存储 | 用途 | 开发回退 |
|------|------|---------|
| **Milvus** | 知识向量库 — 语义检索（E5 768 维嵌入） | InMemoryVectorStore |
| **PostgreSQL** | 用户 / 会话 / 学习记录 / 画像 / 评估结果 | SQLite |
| **Redis** | 缓存（LLM 响应 / 检索结果 / 会话状态） | 内存降级 |
| **文件系统** | 音频文件 / PPT 产物 / 视频 / 用户上传 | — |

### 种子数据量

| 数据类型 | 数量 | 说明 |
|---------|------|------|
| 知识库 Chunks | 1883 | 四科知识点分片（739 knowledge_point + 1144 knowledge_variant），含 metadata.subject / chapter / group |
| 练习题 | 200 | 选择题 / 填空题 / 简答题，覆盖四科 |
| 知识图谱节点 | 613 | 四科知识点节点，含 id / label / group |
| 知识图谱边 | 609 | 先修关系有向边 |
| 知识图谱 Group | 26 | 按章节划分的 group，用于跨群冲突检测 |

---

## 常见问题

**Q: 启动报错 "ModuleNotFoundError"？**
A: 确保已执行 `pip install -e .` 安装所有依赖。若某个库安装失败，项目会自动降级（如 Milvus → InMemory）。

**Q: LLM 返回空或报错？**
A: 检查 `.env` 中的 API 密钥是否正确配置。至少需要讯飞星火或 DeepSeek 其中一个通道（讯飞为主通道，DeepSeek 为兜底）。

**Q: 端口 8002 被占用？**
A: 修改 `py-server/main.py` 中的端口号，并同步修改 `vite.config.ts` 中的 proxy target。

**Q: 前端页面白屏？**
A: 确认后端已启动且 `http://127.0.0.1:8002/api/status` 返回 200。Vite 代理会自动转发 `/api` 请求。

**Q: 如何重置数据？**
A: 删除 `py-server/vectordb_data/` 目录后重启后端，会自动重新加载种子数据。

**Q: TTS 语音朗读不工作？**
A: 确保已安装 MeloTTS（`pip install melotts`）或配置了讯飞 TTS 凭证。执行 `curl http://127.0.0.1:8002/api/tts/status` 可查看引擎状态。

**Q: 演示账号是什么？**
A: 非生产环境默认创建演示账号 `demo` / `demo123456`，可在登录页直接使用。

**Q: 如何选择 LLM 通道？**
A: 默认 `llm_provider=auto` 时以讯飞星火 X2 为主通道、DeepSeek 为兜底（赛题合规要求）。也可在 `py-server/config.json` 中显式指定 `"xfyun"` 或 `"deepseek"`，或通过设置页切换。

**Q: 如何添加新的知识库内容？**
A: 修改 `py-server/seed_data.py` 中的 `SEED_KNOWLEDGE_CHUNKS` 列表，删除 `vectordb_data/` 目录后重启。

---

## 测试

```bash
# 后端全部测试（614+ 个用例，全量 554 passed）
cd py-server
python -m pytest -q

# 运行指定测试文件
python -m pytest tests/test_api_consistency.py -v

# 前端类型检查
cd study-help-pro
npm run type-check

# 前端构建验证
npm run build-only
```

---

## 文档

详细文档位于 `documents/` 目录，包含 50+ 份文档：

### 核心文档

| 文档 | 说明 |
|------|------|
| [系统架构设计文档](documents/系统架构设计文档.md) | 整体架构、模块划分、技术选型 |
| [API 接口手册](documents/API接口手册.md) | 所有 API 端点详细说明 |
| [开发说明书](documents/开发说明书.md) | 开发环境搭建、编码规范、贡献指南 |
| [测试说明书](documents/测试说明书.md) | 测试策略、用例设计、覆盖率 |
| [部署运维手册](documents/部署运维手册.md) | 生产环境部署、监控、故障处理 |
| [快速启动指南](documents/快速启动指南.md) | 精简版启动步骤 |

### 产品与设计

| 文档 | 说明 |
|------|------|
| [产品需求文档 PRD](documents/产品需求文档PRD.md) | 需求分析、功能规格、用户故事 |
| [技术方案文档](documents/技术方案文档.md) | 技术实现方案详细说明 |
| [智能体系统完整说明书](documents/智能体系统完整说明书.md) | 10 节点多智能体设计详解 |
| [设计系统规范](docs/design-system/DESIGN_SYSTEM_v2.md) | 色彩/字体/组件/动效规范 |

### 报告与评审

| 文档 | 说明 |
|------|------|
| [项目全面审查与架构剖析](documents/项目全面审查与架构剖析_2026-07-10.md) | 全面代码审查结果 |
| [竞品分析报告](documents/竞品分析报告.md) | 6 款竞品深度对比 |
| [用户研究报告](documents/用户研究报告.md) | 考生需求调研与分析 |
| [软件杯赛题合规清单](documents/软件杯赛题合规清单.md) | 赛题要求逐项对照 |

---

## 截图

> 以下截图正在准备中，将在 `screenshots/` 目录下提供。

| 功能 | 截图 |
|------|------|
| 对话界面 | `screenshots/chat.png` |
| 资源生成 | `screenshots/resource.png` |
| 知识图谱 | `screenshots/knowledge.png` |
| 学习路径 | `screenshots/learning-path.png` |
| TTS 语音朗读 | `screenshots/tts.png` |

---

## 许可证

本项目为 2026 第十五届中国软件杯 A3 赛题参赛作品，仅供学习和参考。

---

## 致谢

- 出题企业：**科大讯飞股份有限公司**
- 赛题：**A3-基于大模型的个性化资源生成与学习多智能体系统开发**
- 开源项目：MeloTTS、LangGraph、FastAPI、Milvus、Vue 3 等

---

## 镜像版本与回滚（D7）

后端镜像采用**固定 tag**而非 `latest`，便于一键回滚到已知良好版本。

### 构建（注入版本 / 构建日期）

```bash
# 显式指定版本与构建日期（UTC ISO8601）
BUILD_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ) APP_TAG=1.0.1 \
  docker compose build app

# 或仅用默认 tag（APP_TAG 缺省为 1.0.0）
docker compose build app
```

镜像被标记为 `mars408/app:1.0.1`（见 `docker-compose.yml` 的 `image:` 与 `build.args`）。
Dockerfile 同时写入 OCI 标准标签：`org.opencontainers.image.version`、`org.opencontainers.image.created`、`maintainer` 等（可用 `docker inspect` 查看）。

### 查看当前运行版本

```bash
docker compose images app
docker inspect --format '{{index .Config.Labels "org.opencontainers.image.version"}}' mars408/app:1.0.1
```

### 回滚到上一版本

```bash
# 1) 停掉当前（latest 指向的）实例
docker compose down app

# 2) 用上一稳定 tag 重新拉起（例如 1.0.0）
APP_TAG=1.0.0 docker compose up -d app

# 3) 探活确认（compose 已配置 healthcheck + start_period: 60s）
curl -f http://localhost:8002/api/status
```

> 原则：**不要 `docker compose pull` 后直接 `up` latest**——`latest` 不可复现，回滚困难。
> 始终通过 `APP_TAG=<上一稳定版本>` 拉起指定 tag。

### Windows 进程守护（D8）

开发 / Windows 单机部署可用 `py-server/guardian.bat`：循环检测 `:8002` 是否存活，
崩溃则自动重启（基于 `netstat` + `timeout` + `start`，不依赖第三方）。

```bat
cd py-server
guardian.bat
```

---

## 运维可观测性（D4 / D5 / D11）

- **健康检查**：`docker-compose.yml` 的 `app` 服务探活 `GET /api/status`（curl），
  `milvus` 探活 `:9091/healthz`；均设 `start_period`（app 60s / milvus 120s）与 `restart: unless-stopped`。
- **指标端点**：`GET /metrics` 返回 Prometheus 文本格式，暴露
  `http_requests_total` / `http_requests_in_flight` / `http_request_errors_total` /
  `http_request_duration_seconds_{sum,count}`（进程内计数器，无需外部依赖）。
- **结构化日志（D11）**：所有 `netlearn.*` 日志为单行 JSON（`ts`/`level`/`logger`/`msg`），
  启动、请求入口、关键错误均结构化，便于采集到 Loki / ES。
